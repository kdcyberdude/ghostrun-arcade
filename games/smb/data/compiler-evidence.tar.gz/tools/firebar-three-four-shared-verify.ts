/** Shared physical module versus independent source points; activation origins remain explicit conditional metadata. */
import fs from 'node:fs';import crypto from 'node:crypto';import assert from 'node:assert/strict';
import {createFirebarMotor,advanceFirebarMotor,firebarFlameCenters} from '../src/firebar-motion';
const [configPath,out]=process.argv.slice(2),read=(p:string)=>JSON.parse(fs.readFileSync(p,'utf8')),sha=(p:string)=>crypto.createHash('sha256').update(fs.readFileSync(p)).digest('hex');
const config=read(configPath),sourceHashes:Record<string,string>={[configPath]:sha(configPath),'src/firebar-motion.ts':sha('src/firebar-motion.ts'),'data/firebar-motion-rules.json':sha('data/firebar-motion-rules.json'),'tools/firebar-three-four-shared-verify.ts':sha('tools/firebar-three-four-shared-verify.ts')};
const geometry={x:312,y:184,length:6 as const},parameters={direction:-1 as const,initialUnits:768};
const boundary=createFirebarMotor(parameters);for(let i=0;i<150;i++)advanceFirebarMotor(boundary,geometry,parameters,52);assert.deepEqual(boundary,{active:false,units:768});advanceFirebarMotor(boundary,geometry,parameters,53);assert.deepEqual(boundary,{active:true,units:763});
for(let age=2;age<=60;age++){
 const expected=createFirebarMotor(parameters);for(let n=0;n<age;n++)advanceFirebarMotor(expected,geometry,parameters,53);
 for(const [initialUnits,birthDelta]of [[763,1],[773,-1]]){const alternative={direction:-1 as const,initialUnits},motor=createFirebarMotor(alternative);for(let n=0;n<age-birthDelta;n++)advanceFirebarMotor(motor,geometry,alternative,53);assert.deepEqual(firebarFlameCenters(motor,geometry),firebarFlameCenters(expected,geometry));}
}
const cases=[];
for(const spec of config.cases){
 sourceHashes[spec.source]=sha(spec.source);const report=read(spec.source).reports[spec.reportIndex];assert.equal(report.role,spec.role);const motor=createFirebarMotor(parameters);
 let previous=spec.birthNative-1,points=0,rawMax=0,coherent=0,complete=0;const checkpoints=[];
 for(const row of report.rows){
  assert.equal(sha(row.image),row.imageSHA256);const assembly=row.assemblies[0];
  if(row.nativeFrame<spec.birthNative){assert.equal(assembly.points.length,0);continue;}
  for(let frame=previous+1;frame<=row.nativeFrame;frame++)advanceFirebarMotor(motor,geometry,parameters,53);
  previous=row.nativeFrame;const centers=firebarFlameCenters(motor,geometry);let error=0;
  for(const point of assembly.points){const center=centers[point.radiusIndex];error=Math.max(error,Math.abs(center.x-point.actualCenter[0]),Math.abs(center.y-point.actualCenter[1]));points++;}
  rawMax=Math.max(rawMax,error);if(assembly.shapePhaseCandidates.length===1)coherent++;if(assembly.uniqueRadiusIndices.length===6)complete++;
  if(assembly.points.length)checkpoints.push({sourceNativeFrame:row.nativeFrame,sourceTick:row.tick,sourceImage:row.image,sourceImageSHA256:row.imageSHA256,motorAge:row.nativeFrame-spec.birthNative+1,rawCenterErrorPixels:error});
 }
 assert.equal(rawMax,0,`${spec.role} raw source error`);assert.ok(points>400&&complete>70);cases.push({...spec,points,coherent,completeSixNodeViews:complete,rawMaxPixels:rawMax,raw2pxPassed:rawMax<=2,checkpoints});
}
const forecastPath='evidence/firebar-three-four-reserved-forecast.json',forecast=read(forecastPath);sourceHashes[forecastPath]=sha(forecastPath);
const nativeWait=config.cases[2].birthNative-config.cases[0].birthNative;assert.equal(nativeWait,278);assert.equal((712+5*nativeWait)%1024,forecast.reserved37.conditionalSourceNativeOffset);
const result={schema:'three-four-shared-motor-source-conditional-v1',qualification:'Every detected raw center retained; fixed2px source comparison passes. Source birthNative is conditional first-update metadata, NOT an engine timing script or independently observed exact nativecamera. Candidate768 retains763/one-later and773/one-earlier ambiguity. No traversal/collision/fullscene claim. Numeric reserved forecast54 was frozen before capture; ordinal decision poses can differ because7/8frame decision parity swaps.',sourceHashes,geometry,parameters,boundaryRule:{camera52Inactive:true,camera53FirstAdvance763:true,qualification:'Actual shared-module behavior, source threshold remains bracketed by7/8frame camera images.'},cases,allRaw2pxPassed:cases.every(c=>c.raw2pxPassed)};
fs.writeFileSync(out,JSON.stringify(result,null,2)+'\n');console.log(JSON.stringify({out,rawMaxima:cases.map(c=>c.rawMaxPixels),points:cases.reduce((n,c)=>n+c.points,0),coherent:cases.reduce((n,c)=>n+c.coherent,0)},null,2));
