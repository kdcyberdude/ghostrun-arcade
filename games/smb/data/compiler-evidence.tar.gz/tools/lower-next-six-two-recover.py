"""One exact normal-route support cell, with independent camera and pixel witnesses."""
import argparse
import hashlib
import json
import sys
from pathlib import Path

import numpy as np
from PIL import Image

ROOT = Path(__file__).resolve().parent.parent
parser = argparse.ArgumentParser()
parser.add_argument('--verify', action='store_true')
args = parser.parse_args()


def read(path):
    return json.loads((ROOT / path).read_text())


def sha(path):
    return hashlib.sha256((ROOT / path).read_bytes()).hexdigest()


camera_file = 'tools/lower-next-six-two-camera-v7.py'
freeze_file = 'evidence/lower-next-six-two-prospective-freeze.json'
closure_file = 'evidence/lower-next-six-two-closure.json'
for path, digest in read(freeze_file)['files'].items():
    assert sha(path) == digest, path
assert read(closure_file)['allClosed']
# Reuse the exact frozen candidate-independent foreground function; executing
# only definitions never runs its fitting loop or writes an analysis report.
old_argv = sys.argv
sys.argv = [camera_file]
ns = {'__file__': str(ROOT / camera_file)}
exec((ROOT / camera_file).read_text().split('first = image(rows[args.start])')[0], ns)
sys.argv = old_argv
configs = {
    'training': {'trace': 'evidence/local/lower-next-six-two-support-v1-training-2026-11-06T07-09-50.895Z/trace.jsonl',
                 'reports': ['evidence/lower-next-six-two-training.json', 'evidence/lower-next-six-two-training-crossfit.json']},
    'heldout': {'trace': 'evidence/local/lower-next-six-two-support-v1-heldout-2026-11-06T07-09-52.359Z/trace.jsonl',
                'reports': ['evidence/lower-next-six-two-heldout.json', 'evidence/lower-next-six-two-heldout-crossfit.json']},
}
observations = {}
sources = [freeze_file, closure_file, camera_file, 'tools/lower-next-six-two-recover.py',
           'tools/lower-next-six-two-verify.py',
           'tools/lower-next-six-two-mask-calibrate-v7.py',
           'evidence/lower-next-six-two-final-mask-calibration-v7.json',
           'tools/lower-next-six-two-close-camera.py',
           'assets/graphics/graphics-manifest.json', 'assets/graphics/metatiles-palette-018.png',
           'data/observed-levels.json', 'data/observed-upper-rows.json', 'data/observed-lower-supplement.json']
for role, config in configs.items():
    sources += [config['trace']] + config['reports']
    reports = [read(p) for p in config['reports']]
    assert all(r['passedThroughEnd'] and r['allTargetPixelsExcludedFromRegistration']
               and r['codeSha256'] == sha(camera_file) for r in reports)
    maps = [{r['tick']: r for r in report['chain']} for report in reports]
    records = list(map(json.loads, (ROOT / config['trace']).read_text().splitlines()))
    assert not any((r.get('player') or {}).get('cell') == 22 for r in records)
    observations[role] = []
    for row in records:
        tick = row.get('response', {}).get('tick', -1)
        player = row.get('player')
        if tick < 6656:
            continue  # Use a repeat after the declared controller histories diverge.
        if tick <= 6642 or not player or player.get('confidence') != 1 or 'killed' in player.get('annotation', ''):
            continue
        if any(tick not in m for m in maps):
            continue
        pair = [m[tick] for m in maps]
        if not all(r['eightAnchorEndpoint'] and r['targetImageEvidenceEligible'] for r in pair):
            continue
        origins = []
        for y in range(240):
            candidates = {c for r in pair for c in r['cameraCandidatesByPixelRow'][y]}
            origins.append(next(iter(candidates)) if len(candidates) == 1 else None)
        path = row['image']
        im = np.asarray(Image.open(ROOT / path).convert('RGB'))
        mask = ns['foreground'](im, camera=False)
        mask[max(0, player['visibleTop'] - 4):min(240, player['visibleBottom'] + 4),
             max(0, player['visibleLeft'] - 4):min(256, player['visibleRight'] + 4)] = True
        observations[role].append({'tick': tick, 'nativeFrame': row['nativeFrame'], 'image': path,
                                   'imageSha256': sha(path), 'origins': origins,
                                   'originalChainImage': config['reports'][0],
                                   'independentCrossfitImage': config['reports'][1],
                                   'imageRGB': im, 'dynamicMask': mask})


def actual_proof(x, y, width=16, height=16):
    seen = {role: [[{} for _ in range(width)] for _ in range(height)] for role in observations}
    for role, scene in observations.items():
        for index, obs in enumerate(scene):
            for dy in range(height):
                camera = obs['origins'][y + dy]
                if camera is None:
                    continue
                for dx in range(width):
                    sx = x + dx - camera
                    if not 16 <= sx < 240 or obs['dynamicMask'][y + dy, sx]:
                        continue
                    rgb = tuple(map(int, obs['imageRGB'][y + dy, sx]))
                    seen[role][dy][dx].setdefault(rgb, []).append(index)
    truth = np.zeros((height, width, 3), dtype='uint8')
    proven = np.zeros((height, width), dtype=bool)
    refs = {role: [[[] for _ in range(width)] for _ in range(height)] for role in observations}
    conflicts = []
    for dy in range(height):
        for dx in range(width):
            colors = {rgb for role in seen for rgb in seen[role][dy][dx]}
            if len(colors) > 1:
                conflicts.append({'offset': [dx, dy], 'RGBValues': [list(c) for c in sorted(colors)]})
            elif colors:
                rgb = next(iter(colors))
                truth[dy, dx] = rgb
                for role in refs:
                    refs[role][dy][dx] = seen[role][dy][dx].get(rgb, [])[:2 if role == 'training' else 1]
                proven[dy, dx] = len(refs['training'][dy][dx]) == 2 and len(refs['heldout'][dy][dx]) == 1
    return {'complete': bool(proven.all()), 'provenPixels': int(proven.sum()), 'totalPixels': width * height,
            'contradictionCount': len(conflicts), 'contradictions': conflicts,
            'unwitnessedOffsets': np.argwhere(~proven)[:, ::-1].tolist(), 'pixelWitnesses': refs}, truth


manifest = read('assets/graphics/graphics-manifest.json')
rects = {m['id']: m['rect'] for m in manifest['metatiles']}
atlas = np.asarray(Image.open(ROOT / 'assets/graphics/metatiles-palette-018.png').convert('RGB'))


def tile(mid):
    x, y, w, h = rects[mid]
    return atlas[y:y + h, x:x + w]


result = {'schema': 'observed-six-cell-pit-boundary-v1', 'status': 'read-only-candidate-parent-integration-required',
          'sourceWitnesses': {role: [{k: v for k, v in o.items() if k not in ['imageRGB', 'dynamicMask']}
                                     for o in scene] for role, scene in observations.items()},
          'thresholds': {'RGBPixelsPerWholeCell': 256, 'RGBTolerance': 0, 'distinctTrainingTicksPerPixel': 2,
                         'freshIndependentHeldoutTicksPerPixel': 1, 'wholeKnownAnchorsPerImage': 8},
          'cameraTargetExclusion': 'Entire row208..223 never enters registration, including every target and changed fragment. Actual independent non-target row14 may extend the camera mosaic. No fixed raster band or common auxiliary calibration.',
          'wholeCells': [], 'unresolvedCells': [], 'originalStaticFragmentInventory': [],
          'acceptedRemovals': [], 'consistentOverlapsPreserved': []}
for col in range(139, 145):
    proof, truth = actual_proof(col * 16, 208)
    aliases = [mid for mid in rects if np.array_equal(tile(mid), truth)] if proof['complete'] else []
    background = bool(proof['complete'] and np.all(truth == [0, 0, 0]))
    mid = 0 if background else 84 if aliases == [84] else None
    cell = {'level': '6-2', 'area': 'main', 'col': col, 'row': 13,
            'atlas': 'metatiles-palette-018.png', 'metatileId': mid, 'visualAliases': aliases,
            'classification': 'uniform-observed-background' if background else 'unique-visible-metatile',
            'proof': proof,
            'collisionProvenance': ('All256RGBpixels are actual backgroundblack in both independent histories. This proves visible absence of static artwork, not absence of invisible blocks; pit collision semantics remain inferred from observed layout context.' if background else 'Suppliedground84class and observed terrain context imply solidity; bitmap equality alone does not establish exact native collision timing.')}
    if proof['complete'] and not proof['contradictionCount'] and mid is not None:
        result['wholeCells'].append(cell)
    else:
        result['unresolvedCells'].append(cell)
for source in ['data/observed-levels.json', 'data/observed-upper-rows.json', 'data/observed-lower-supplement.json']:
    segment = next(s for l in read(source)['levels'] if l['id'] == '6-2' for s in l['segments'] if s['id'] == 'main')
    for field in ['freeTiles', 'decorations', 'tile8Overrides', 'patternOverrides']:
        for index, piece in enumerate(segment.get(field, [])):
            if isinstance(piece, dict):
                x, y, width, height = piece['x'], piece['y'], 16, 16
            else:
                x, y, width, height = piece[0] * 8, piece[1] * 8, 8, 8
            if not (x < 2320 and x + width > 2224 and y < 224 and y + height > 208):
                continue
            assert 208 <= y and y + height <= 224, 'Cross-learning-band fragment cannot qualify'
            if isinstance(piece, dict):
                patch = tile(piece['metatileId'])
            else:
                image_path = 'assets/graphics/' + piece[3]
                sources.append(image_path)
                image = np.asarray(Image.open(ROOT / image_path).convert('RGB'))
                px, py = piece[2] % 16 * 8, piece[2] // 16 * 8
                patch = image[py:py + 8, px:px + 8]
            item = {'level': '6-2', 'area': 'main', 'sourceFile': source, 'sourceField': field,
                    'sourceIndex': index, 'match': piece, 'footprint': [x, y, width, height]}
            result['originalStaticFragmentInventory'].append(item)
            footprint_proof, observed = actual_proof(x, y, width, height)
            item = {**item, 'referenceProof': footprint_proof}
            assert footprint_proof['complete'] and footprint_proof['contradictionCount'] == 0
            if np.array_equal(patch, observed):
                result['consistentOverlapsPreserved'].append(item)
            else:
                result['acceptedRemovals'].append({**item, 'action': 'remove-whole-fragment',
                                                  'opaqueSourcePixelsDifferentFromObservedReplacement': int(np.any(patch != observed, axis=2).sum())})
result['sourceHashes'] = {p: sha(p) for p in sorted(set(sources))}
FILE = 'data/lower-next-six-two-support.json'
if args.verify:
    assert read(FILE) == result, 'Exact export does not reproduce'
else:
    (ROOT / FILE).write_text(json.dumps(result, indent=2) + '\n')
print(json.dumps({'acceptedWholeCells': [(c['col'], c['row'], c['metatileId']) for c in result['wholeCells']],
                  'unresolvedCells': len(result['unresolvedCells']),
                  'wholeRemovals': len(result['acceptedRemovals']),
                  'consistentOverlapsPreserved': len(result['consistentOverlapsPreserved'])}))
