"""Keep every admissible parent when checking a reference-camera chain."""
import argparse,hashlib,json
from pathlib import Path
ROOT=Path(__file__).resolve().parent.parent
p=argparse.ArgumentParser();p.add_argument('reports',nargs='+');p.add_argument('--out',required=True);a=p.parse_args()
out={'schema':'six-one-unrestricted-camera-backward-closure-v1','runs':[],'mapPromoted':False}
for file in a.reports:
 report=json.loads((ROOT/file).read_text());assert report['passedThroughEnd'];chain=report['chain'];allowed=set(chain[-1]['latestCameraCandidates']);reverse=[]
 for q in reversed(chain):
  hypotheses=[h for h in q['hypotheses']if h['latestCamera']in allowed];assert hypotheses
  current=sorted({h['latestCamera']for h in hypotheses});allowed={v for h in hypotheses for v in h['parentLatestCandidates']}
  reverse.append({'tick':q['tick'],'survivingLatestCandidates':current,'parentCandidates':sorted(allowed),'retainedHypotheses':len(hypotheses),'periodicEightPixelAlias':max(current)-min(current)>=8})
 assert allowed=={0},'Not closed to independent zero anchor'
 endpoint=chain[-1];assert endpoint['eightAnchorEndpoint'] and endpoint['targetImageEvidenceEligible']
 assert all(len(v)==1 for v in endpoint['cameraCandidatesByPixelRow'][208:240])
 assert not any(r['periodicEightPixelAlias']for r in reverse)
 out['runs'].append({'report':file,'reportSha256':hashlib.sha256((ROOT/file).read_bytes()).hexdigest(),'backward':list(reversed(reverse)),'independentCameraZeroClosed':True,'endpointWholeAnchors':min(len(h['wholeNonuniformEstablishedAnchors'])for h in endpoint['hypotheses']),'uniqueExcludedTargetRowOrigins':endpoint['cameraCandidatesByPixelRow'][208:224],'uniqueIndependentRow14Origins':endpoint['cameraCandidatesByPixelRow'][224:240],'unrenderedLatestCandidatesRetained':endpoint['latestCameraCandidates']})
out['allClosed']=True;(ROOT/a.out).write_text(json.dumps(out,indent=2)+'\n');print(json.dumps({'allClosed':True,'histories':len(out['runs']),'mapPromoted':False}))
