"""Describe source static assembly after excluding ALL independently detected opaque flame pixels."""
import hashlib,json,pathlib,sys
import numpy as np
from PIL import Image
root=pathlib.Path(__file__).resolve().parent.parent
reg=json.loads((root/sys.argv[1]).read_text());measured=json.loads((root/sys.argv[2]).read_text())
patterns=[np.asarray(Image.open(root/f'assets/graphics/special/sprite-fireball_or_firebar-{p}.png').convert('RGBA'))for p in range(4)]
atlas=np.asarray(Image.open(root/'assets/graphics/metatiles-palette-006.png').convert('RGB'));meta=json.loads((root/'assets/graphics/graphics-manifest.json').read_text())['metatiles']
reports=[]
for report in measured['reports']:
 ws=reg['sourceWitnesses'][report['role']];colors=[[set()for _ in range(16)]for _ in range(16)];proof={}
 for row in report['rows']:
  if row['assemblies'][0]['uniqueRadiusIndices'] != list(range(6)):continue
  w=ws[row['witnessIndex']];im=np.asarray(Image.open(w['image']).convert('RGB'));mask=np.zeros((240,256),bool)
  for assembly in row['assemblies']:
   for point in assembly['points']:
    x,y=point['sourceTopLeft']
    for phase in point['spritePhases']:mask[y:y+8,x:x+8]|=patterns[phase][:,:,3]>0
  for yy in range(16):
   cam=w['origins'][176+yy]
   if cam is None:continue
   for xx in range(16):
    sx=304+xx-cam
    if 0<=sx<256 and not mask[176+yy,sx]:
     value=tuple(map(int,im[176+yy,sx]));colors[yy][xx].add(value);proof.setdefault((xx,yy),[row['witnessIndex'],sx,176+yy,list(value)])
 unique=[[xx,yy,*proof[(xx,yy)]]for yy in range(16)for xx in range(16)if len(colors[yy][xx])==1]
 fits=[]
 for t in meta:
  x,y,_,_=t['rect'];p=atlas[y:y+16,x:x+16];bad=[[q[0],q[1],q[-1],p[q[1],q[0]].tolist()]for q in unique if not np.array_equal(p[q[1],q[0]],q[-1])];fits.append({'tile':t['id'],'mismatches':len(bad)})
 reports.append({'role':report['role'],'uniqueDirectPixels':len(unique),'unseenOrAmbiguous':256-len(unique),'pixelWitnesses':unique,'bestAssetFits':sorted(fits,key=lambda t:(t['mismatches'],t['tile']))[:12]})
result={'schema':'three-four-base-masked-source-proof-v1','sourceRegistry':sys.argv[1],'sourceRegistrySHA256':hashlib.sha256((root/sys.argv[1]).read_bytes()).hexdigest(),'measurement':sys.argv[2],'measurementSHA256':hashlib.sha256((root/sys.argv[2]).read_bytes()).hexdigest(),'toolSHA256':hashlib.sha256(pathlib.Path(__file__).read_bytes()).hexdigest(),'sourceHashes':{p:hashlib.sha256((root/p).read_bytes()).hexdigest()for p in ['assets/graphics/graphics-manifest.json','assets/graphics/metatiles-palette-006.png',*[f'assets/graphics/special/sprite-fireball_or_firebar-{i}.png'for i in range(4)]]},'worldRect':[304,176,16,16],'qualification':'Independent camera; every detected opaque flame pixel masked including white RGB. Static source pixels never choose camera. Best asset fits descriptive; no canonical base inference accepted.','reports':reports}
(root/sys.argv[3]).write_text(json.dumps(result,indent=2)+'\n');print(json.dumps([{k:v for k,v in r.items()if k!='pixelWitnesses'}for r in reports],indent=2))
