/** Descriptive signed motor fits; never infer camera or production activation. */
import fs from 'node:fs';import crypto from 'node:crypto';import assert from 'node:assert/strict';
const [source,out]=process.argv.slice(2);assert.ok(source&&out,'source and output required');
const read=p=>JSON.parse(fs.readFileSync(p)),sha=p=>crypto.createHash('sha256').update(fs.readFileSync(p)).digest('hex');
const measurements=read(source),lookupPath='data/firebar-motion-rules.json',lookup=read(lookupPath).lookup;
const reports=measurements.reports.map(report=>({role:report.role,assemblies:report.assemblies.map((summary,index)=>{
 const coherent=report.rows.filter(row=>row.assemblies[index].shapePhaseCandidates.length===1),signedFits={};
 assert.ok(summary.completeSixNodeTicks.length>0);assert.ok(coherent.length>0);
 for(const direction of[-1,1]){
  const offsets=Array.from({length:1024},(_,n)=>n).filter(offset=>coherent.every(row=>Math.floor(((offset+direction*5*row.nativeFrame)%1024+1024)%1024/32)===row.assemblies[index].shapePhaseCandidates[0]));
  signedFits[direction]=offsets.map(offset=>({offset,maxUnshiftedRawCenterErrorPixels:Math.max(...report.rows.flatMap(row=>{
   const phase=Math.floor(((offset+direction*5*row.nativeFrame)%1024+1024)%1024/32);
   return row.assemblies[index].points.map(point=>Math.max(...point.relative.map((v,c)=>Math.abs(v-lookup[phase][point.radiusIndex][c]))));
  }))}));
 }
 return {actualPivot:summary.actualPivot,coherentObservations:coherent.length,centerSamples:summary.centerSamples,completeSixNodeViews:summary.completeSixNodeTicks.length,signed5UnitCounterFitsAtNativeZero:signedFits};
})}));
const result={schema:'five-four-extra-descriptive-direction-fit-v1',qualification:'Descriptive source-native offsets only. Uses frozen source points and actual native accounting. No production initial phase, camera refinement, prospective validation, collision or traversal claim. Raw tolerance remains2px.',sourceHashes:{[source]:sha(source),[lookupPath]:sha(lookupPath),'tools/firebar-five-four-extra-direction.mjs':sha('tools/firebar-five-four-extra-direction.mjs')},reports};
fs.writeFileSync(out,JSON.stringify(result,null,2)+'\n');console.log(JSON.stringify(result,null,2));
