/** Read-only 3-2 block inventory: authorized reference controls/images only. */
import fs from 'node:fs';import path from 'node:path';import crypto from 'node:crypto';import {spawn} from 'node:child_process';import {createInterface} from 'node:readline';
import {findPlayer} from './physics-reference-measure.mjs';
const sha=f=>crypto.createHash('sha256').update(fs.readFileSync(f)).digest('hex');
const actionsFile='data/observed-winning-inputs.json',actions=JSON.parse(fs.readFileSync(actionsFile)).actions;
const dense=fs.readFileSync('evidence/local/reference-campaign-dense/trace.jsonl','utf8').trim().split('\n').map(JSON.parse);
const out=`evidence/local/three-two-block-${new Date().toISOString().replaceAll(':','-')}`;fs.mkdirSync(out,{recursive:true});
const child=spawn('./run-model.sh',['/home/kd/Desktop/proj/llm_gameplay/roms/mario.nes'],{stdio:['pipe','pipe',fs.openSync(out+'/stderr.log','w')]}),queue=[];let receiver,sequence=0,frame=0,experiment='initial';
createInterface({input:child.stdout}).on('line',line=>{if(receiver){const r=receiver;receiver=undefined;r(line);}else queue.push(line);});
async function request(command,stage='manual'){
  child.stdin.write(JSON.stringify(command)+'\n');const response=JSON.parse(queue.length?queue.shift():await new Promise(r=>receiver=r));if(!response.ok)throw Error(JSON.stringify(response));
  if(command.op==='reset')frame=0;else frame+=response.frames_advanced??0;
  if(response.image?.path){const p=`${out}/${String(sequence).padStart(5,'0')}-${experiment}-t${response.tick}.png`;fs.copyFileSync(response.image.path,p);response.image.capture_path=path.resolve(p);}
  const row={sequence:sequence++,timestamp:new Date().toISOString(),experiment,stage,request:command,response,nativeFrame:frame};
  if(stage!=='known-prefix'&&response.image?.capture_path)row.player=findPlayer(response.image.capture_path);
  fs.appendFileSync(out+'/trace.jsonl',JSON.stringify(row)+'\n');return row;
}
async function prefix(tick,name){experiment=name??`prefix-${tick}`;await request({op:'reset'},'reset');const groups=[];for(const [mask] of actions.slice(0,tick)){const last=groups.at(-1);if(last?.mask===mask&&last.ticks<240)last.ticks++;else groups.push({op:'step',mask,ticks:1});}for(const c of groups)await request(c,'known-prefix');const row=await request({op:'observe'},'prefix-check'),source=dense.find(x=>x.response.tick===tick),expectedFrames=actions.slice(0,tick).reduce((n,x)=>n+x[1],0);const check={tick,nativeFrame:row.nativeFrame,expectedFrames,identicalPng:sha(row.response.image.capture_path)===sha(source.response.image.capture_path)};if(!check.identicalPng||frame!==expectedFrames)throw Error(JSON.stringify(check));return {...row,check};}
fs.writeFileSync(out+'/metadata.json',JSON.stringify({createdUtc:new Date().toISOString(),tool:'tools/three-two-block-reference.mjs',toolSha256:sha('tools/three-two-block-reference.mjs'),actionsFile,actionsSha256:sha(actionsFile),purpose:'Individually bonk opening 3-2 blocks. No source state APIs; known fresh standard input replay plus manual controls. Block identities anchored to supplied observed geometry; item/HUD evidence required.',originalFiles:['data/block-contents.json','data/levels.json','src/simulation.ts'].map(file=>({file,sha256:sha(file)}))},null,2)+'\n');
console.log(JSON.stringify({directory:path.resolve(out),hello:(await request({op:'hello'},'hello')).response}));
const input=createInterface({input:process.stdin});try{for await(const line of input){if(!line.trim())continue;const command=JSON.parse(line);if(command.op==='quit')break;const row=command.prefix!==undefined?await prefix(command.prefix,command.name):await request(command);console.log(JSON.stringify({sequence:row.sequence,tick:row.response.tick,nativeFrame:row.nativeFrame,framesAdvanced:row.response.frames_advanced,image:row.response.image?.capture_path,player:row.player,check:row.check,terminal:row.response.terminal}));}}finally{child.stdin.end();child.kill();}
