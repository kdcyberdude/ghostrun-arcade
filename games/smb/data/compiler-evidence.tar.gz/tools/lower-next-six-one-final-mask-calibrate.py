"""Supplied-art coverage check for the frozen, candidate-independent actor mask."""
import hashlib,json,sys
from pathlib import Path
import numpy as np
from PIL import Image
ROOT=Path(__file__).resolve().parent.parent
file='tools/lower-next-six-one-camera-v9.py';sys.argv=[file];ns={'__file__':str(ROOT/file)};exec((ROOT/file).read_text().split('first = image(rows[args.start])')[0],ns)
checks=[]
def check(label,sprite):
    im=np.zeros((240,256,3),dtype='uint8');height,width=sprite.shape[:2];opaque=sprite[:,:,3]>0
    im[100:100+height,100:100+width][opaque]=sprite[:,:,:3][opaque]
    mask=ns['foreground'](im,camera=False)[100:100+height,100:100+width]
    checks.append({'label':label,'opaquePixels':int(opaque.sum()),'unmaskedOpaquePixels':int((opaque&~mask).sum())})
for direction in ['left','right']:
    sheet=np.asarray(Image.open(ROOT/f'assets/graphics/player-mario-{direction}.png').convert('RGBA'))
    for cell in range(26):
        x=cell%13*16;y=cell//13*32;check(f'providedMario/{direction}/{cell}',sheet[y:y+32,x:x+16])
for palette,cells in [('0f-1a-30-27',[24,25,32,33]),('0f-16-30-27',[6,7,8,9])]:
    sheet=np.asarray(Image.open(ROOT/f'assets/graphics/sprite-tiles-{palette}.png').convert('RGBA'))
    for cell in cells:
        sprite=np.zeros((24,16,4),dtype='uint8');tiles=ns['tables']['enemy_cells'][cell]['tiles']
        for i,tid in enumerate(tiles):
            part=sheet[tid//16*8:tid//16*8+8,tid%16*8:tid%16*8+8]
            if i%2 and tid==tiles[i-1]:part=part[:,::-1]
            sprite[i//2*8:i//2*8+8,i%2*8:i%2*8+8]=part
        for flip in [False,True]:check(f'providedEnemy/{palette}/{cell}/flip{flip}',sprite[:,::-1]if flip else sprite)
for index,coin in enumerate(ns['coin_templates']):
    sprite=np.concatenate([coin,np.where(ns['coin_mask'],255,0)[:,:,None]],axis=2).astype('uint8');check(f'providedCoin194/paletteAssignment{index}',sprite)
assert all(c['unmaskedOpaquePixels']==0 for c in checks)
out={'schema':'frozen-six-one-provided-foreground-coverage-check','checks':checks,'passed':True,'cameraCodeSha256':hashlib.sha256((ROOT/file).read_bytes()).hexdigest(),'scope':'Provided-art mask coverage only. Actual captured poses and all established non-target RGB remain separately checked; this does not assert every possible future actor pose or collision behavior.'}
(ROOT/'evidence/lower-next-six-one-final-mask-calibration.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps({'providedFormsChecked':len(checks),'unmaskedOpaquePixels':0,'passed':True}))
