"""Whole supplied cell34 assembly matches on independently camera-registered native PNGs; no runtime edits."""
import collections,hashlib,json,pathlib,sys
import numpy as np
from PIL import Image
root=pathlib.Path(__file__).resolve().parent.parent
read=lambda p:json.loads((root/p).read_text())
sha=lambda p:hashlib.sha256((root/p).read_bytes()).hexdigest()
registry_path,out=sys.argv[1:3];registry=read(registry_path);tables=read('assets/graphics/tables.json');patterns=[];dedup={};assets={}
for path in sorted((root/'assets/graphics').glob('enemy-table-*.png')):
 if path.name.endswith('index.png'):continue
 assets[str(path.relative_to(root))]=sha(path)
 sheet=np.asarray(Image.open(path).convert('RGBA'));cell=34;raw=sheet[(cell//11)*24:(cell//11+1)*24,(cell%11)*16:(cell%11+1)*16]
 for symmetry in range(3):
  assembled=raw.copy()
  for row in range(3):
   if tables['enemy_cells'][cell]['tiles'][row*2]==tables['enemy_cells'][cell]['tiles'][row*2+1]:
    if symmetry==1:assembled[row*8:row*8+8,8:]=assembled[row*8:row*8+8,8:][:,::-1]
    if symmetry==2:assembled[row*8:row*8+8,:8]=assembled[row*8:row*8+8,:8][:,::-1]
  for flip_x in [False,True]:
   for flip_y in [False,True]:
    body=assembled[8:24].copy();body=body[:,::-1]if flip_x else body;body=body[::-1]if flip_y else body
    key=body.tobytes();variant={'sheet':str(path.relative_to(root)),'cell':34,'rowSymmetry':symmetry,'flipX':flip_x,'flipY':flip_y}
    if key in dedup:patterns[dedup[key]]['variants'].append(variant);continue
    mask=body[:,:,3]>0;opaque=np.argwhere(mask)
    if len(opaque)<100:continue
    rgb=body[:,:,:3];counts=collections.Counter(map(tuple,rgb[mask]));rare=min(counts,key=counts.get);ay,ax=map(int,np.argwhere(mask&np.all(rgb==rare,axis=2))[0]);dedup[key]=len(patterns);patterns.append({'rgb':rgb,'opaque':opaque,'anchor':[ay,ax],'variants':[variant]})
reports=[]
for role,witnesses in registry['sourceWitnesses'].items():
 rows=[]
 for index,w in enumerate(witnesses):
  assert sha(w['image'])==w['imageSha256'];im=np.asarray(Image.open(w['image']).convert('RGB'));found={};unregistered=[]
  for pattern in patterns:
   rgb,opaque=pattern['rgb'],pattern['opaque'];ay,ax=pattern['anchor'];pos=np.argwhere(np.all(im[48:240]==rgb[ay,ax],axis=2));ys,xs=pos[:,0]+48-ay,pos[:,1]-ax;valid=(xs>=0)&(ys>=48)&(xs+16<=256)&(ys+16<=240);ys,xs=ys[valid],xs[valid]
   for yy,xx in opaque:
    valid=np.all(im[ys+yy,xs+xx]==rgb[yy,xx],axis=1);ys,xs=ys[valid],xs[valid]
   for sx,sy in zip(xs,ys):
    origins={w['origins'][int(sy)+int(yy)]for yy in np.unique(opaque[:,0])}
    match={'screenBodyOrigin':[int(sx),int(sy)],'opaquePixels':len(opaque),'opaqueRGBMismatches':0,'variants':pattern['variants']}
    if None in origins or len(origins)!=1:unregistered.append({**match,'rowOrigins':sorted(origins,key=lambda x:-1 if x is None else x)});continue
    cam=next(iter(origins));key=(int(sx)+cam,int(sy));record=found.setdefault(key,{**match,'worldLeft':key[0],'actualBodyTopY':key[1],'rowOrigin':cam,'worldGeometricCenterX':key[0]+8,'variants':[]});record['variants']+=pattern['variants']
  rows.append({'witnessIndex':index,'tick':w['tick'],'nativeFrame':w['nativeFrame'],'image':w['image'],'imageSHA256':w['imageSha256'],'matches':list(found.values()),'wholeArtUnregisteredMatches':unregistered})
 identities=[]
 for x in sorted({match['worldLeft']for row in rows for match in row['matches']}):
  samples=[{'tick':row['tick'],'nativeFrame':row['nativeFrame'],'bodyTopY':m['actualBodyTopY'],'image':row['image'],'imageSHA256':row['imageSHA256'],'opaquePixels':m['opaquePixels']}for row in rows for m in row['matches']if m['worldLeft']==x]
  identities.append({'worldLeft':x,'geometricCenterX':x+8,'wholeArtSamples':len(samples),'uniqueBodyTopYs':sorted({s['bodyTopY']for s in samples}),'minimumOpaquePixels':min(s['opaquePixels']for s in samples),'samples':samples})
 reports.append({'role':role,'identities':identities,'rows':rows})
result={'schema':'three-four-podoboo-whole-art-inventory-v1','sourceRegistry':registry_path,'sourceRegistrySHA256':sha(registry_path),'toolSHA256':sha('tools/podoboo-three-four-inventory.py'),'sourceAssets':assets,'tablesSHA256':sha('assets/graphics/tables.json'),'method':'Entire supplied16x16opaque cell34body, multipart row symmetry andglobalX/Yflips; everyopaque pixel exactRGB. Horizontal position only fromall-hypothesis unique independentstaticcamera across everyopaque sprite row. No spritechooses camera; no initialstate or cycle inference.','patternCount':len(patterns),'reports':reports}
(root/out).write_text(json.dumps(result,indent=2)+'\n');print(json.dumps({'out':out,'patterns':len(patterns),'reports':[{'role':r['role'],'identities':[{k:v for k,v in i.items()if k!='samples'}for i in r['identities']]}for r in reports]},indent=2))
