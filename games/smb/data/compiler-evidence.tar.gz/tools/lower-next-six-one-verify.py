"""Independent direct-image, target-exclusion and controller accounting checks."""
import hashlib
import json
from pathlib import Path

import numpy as np
from PIL import Image

ROOT = Path(__file__).resolve().parent.parent
FILE = 'data/lower-next-six-one-support.json'


def read(path):
    return json.loads((ROOT / path).read_text())


def sha(path):
    return hashlib.sha256((ROOT / path).read_bytes()).hexdigest()


doc = read(FILE)
for path, digest in doc['sourceHashes'].items():
    assert sha(path) == digest, path
freeze = read('evidence/lower-next-six-one-prospective-freeze.json')
for path, digest in freeze['files'].items():
    assert sha(path) == digest, path
closure = read('evidence/lower-next-six-one-closure.json')
assert closure['allClosed']
auxiliary = read('evidence/lower-next-six-one-stationary-freeze.json')
for path,digest in auxiliary['files'].items():
    assert sha(path)==digest,path
assert read('evidence/lower-next-six-one-stationary-closure.json')['allClosed']
assert len(closure['runs'])==4
assert len(doc['wholeCells']) == 1 and not doc['unresolvedCells']
cell = doc['wholeCells'][0]
assert (cell['level'], cell['area'], cell['col'], cell['row'], cell['metatileId']) == ('6-1', 'main', 155, 13, 84)
manifest = read('assets/graphics/graphics-manifest.json')
rect = next(m['rect'] for m in manifest['metatiles'] if m['id'] == 84)
atlas = np.asarray(Image.open(ROOT / 'assets/graphics/metatiles-palette-018.png').convert('RGB'))
x, y, w, h = rect
ground = atlas[y:y + h, x:x + w]
images, chains = {}, {}
pixel_checks = 0


def verify(proof, wx, wy, width, height):
    global pixel_checks
    assert proof['complete'] and proof['provenPixels'] == proof['totalPixels'] == width * height
    assert not proof['contradictionCount'] and not proof['unwitnessedOffsets']
    for dy in range(height):
        for dx in range(width):
            for role, minimum in [('training', 2), ('heldout', 1)]:
                indices = proof['pixelWitnesses'][role][dy][dx]
                assert len(indices) >= minimum
                assert len({doc['sourceWitnesses'][role][i]['tick'] for i in indices}) >= minimum
                for index in indices:
                    obs = doc['sourceWitnesses'][role][index]
                    if role=='heldout':assert obs['tick']>=6370
                    if obs['image'] not in images:
                        assert sha(obs['image']) == obs['imageSha256']
                        images[obs['image']] = np.asarray(Image.open(ROOT / obs['image']).convert('RGB'))
                    camera = obs['origins'][wy + dy]
                    assert camera is not None and 16 <= wx + dx - camera < 240
                    for path in [obs['originalChainImage'], obs['independentCrossfitImage']]:
                        if path not in chains:
                            report = read(path)
                            assert report['passedThroughEnd'] and report['allTargetPixelsExcludedFromRegistration']
                            chains[path] = {r['tick']: r for r in report['chain']}
                            seed = report.get('seedMosaic')
                            if seed:
                                assert sha(seed)==report['seedMosaicSha256']
                                assert not np.any(np.load(ROOT/seed)['known'][208:224])
                            mosaic = report['independentMosaic']
                            if mosaic:
                                assert sha(mosaic) == report['independentMosaicSha256']
                                assert not np.any(np.load(ROOT / mosaic)['known'][208:224])
                        row = chains[path][obs['tick']]
                        assert row['eightAnchorEndpoint'] and row['targetImageEvidenceEligible']
                        assert row['cameraCandidatesByPixelRow'][wy + dy] == [camera]
                        assert all(len(h['wholeNonuniformEstablishedAnchors']) >= 8 for h in row['hypotheses'])
                    actual = images[obs['image']][wy + dy, wx + dx - camera]
                    assert np.array_equal(actual, ground[(wy + dy) % 16, (wx + dx) % 16])
                    pixel_checks += 1


verify(cell['proof'], 2480, 208, 16, 16)
assert cell['visualAliases'] == [84]
assert not doc['acceptedRemovals']
for piece in doc['consistentOverlapsPreserved']:
    source = read(piece['sourceFile'])
    segment = next(s for l in source['levels'] if l['id'] == '6-1' for s in l['segments'] if s['id'] == 'main')
    assert segment[piece['sourceField']][piece['sourceIndex']] == piece['match']
    verify(piece['referenceProof'], *piece['footprint'])
winning = read('data/observed-winning-inputs.json')['actions']
names = ['up', 'down', 'left', 'right', 'a', 'b', 'x', 'y', 'start', 'select']
prefixes = 0
for path in doc['sourceHashes']:
    if not (path.startswith('evidence/local/') and path.endswith('trace.jsonl')):
        continue
    total, prefix, endpoint = 0, [], None
    records = list(map(json.loads, (ROOT / path).read_text().splitlines()))
    for row in records:
        req, rep = row['request'], row['response']
        if req['op'] == 'reset':
            total = 0
        total += rep.get('frames_advanced', 0)
        assert row['nativeFrame'] == total
        if req['op'] == 'step':
            mask = sum(1 << names.index(button) for button in req['buttons'])
            assert rep['applied_masks'] == [mask] * req['ticks']
            assert 7 * req['ticks'] <= rep['frames_advanced'] <= 8 * req['ticks']
            if row['mode'] in ['prefix', 'endpoint']:
                prefix += rep['applied_masks']
        if row['mode'] == 'endpoint':
            endpoint = row
        assert (row.get('player') or {}).get('cell') != 22
    prefix_tick=endpoint['response']['tick']
    assert prefix_tick in [6348,6364]
    assert prefix == [a[0] for a in winning[:prefix_tick]]
    assert endpoint['nativeFrame'] == sum(a[1] for a in winning[:prefix_tick])
    dense = next(json.loads(line) for line in (ROOT / 'evidence/local/reference-campaign-dense/trace.jsonl').read_text().splitlines()
                 if json.loads(line)['response'].get('tick') == prefix_tick)
    assert sha(endpoint['image']) == sha(dense['response']['image']['capture_path'])
    assert records[-1]['response']['tick'] == ({6348:6357,6364:6373}[prefix_tick])
    assert records[-1]['player']['confidence'] == 1 and records[-1]['player']['cell'] == 23
    prefixes += 1
report = {'export': FILE, 'exportSha256': sha(FILE), 'wholeRecoveredCells': 1,
          'directRGBWitnessChecks': pixel_checks, 'RGBMismatchCount': 0,
          'independentFreshStandardPrefixes': prefixes, 'allFourCameraChainsClosed': True,
          'targetRowNeverEnteredCameraMosaics': True, 'minimumWholeAnchors': 8,
          'consistentOriginalWholeFragmentsPreserved': len(doc['consistentOverlapsPreserved']),
          'unprovedOrClippedRemovals': 0, 'allFrozenSourcesUnchanged': True,
          'sharedNonTargetStationaryCalibrationDisclosed': True, 'browserIntegrationStillRequired': True}
(ROOT / 'evidence/lower-next-six-one-verification.json').write_text(json.dumps(report, indent=2) + '\n')
print(json.dumps(report))
