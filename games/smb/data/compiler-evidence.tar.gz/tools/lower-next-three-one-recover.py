"""One exact normal-route support cell, with independent camera and pixel witnesses."""
import argparse
import hashlib
import json
import sys
from pathlib import Path

import numpy as np
from PIL import Image

ROOT = Path(__file__).resolve().parent.parent
parser = argparse.ArgumentParser()
parser.add_argument('--verify', action='store_true')
args = parser.parse_args()


def read(path):
    return json.loads((ROOT / path).read_text())


def sha(path):
    return hashlib.sha256((ROOT / path).read_bytes()).hexdigest()


camera_file = 'tools/lower-next-three-one-camera-v5.py'
freeze_file = 'evidence/lower-next-three-one-prospective-freeze-v4.json'
closure_file = 'evidence/lower-next-three-one-v4-closure.json'
for path, digest in read(freeze_file)['files'].items():
    assert sha(path) == digest, path
assert read(closure_file)['allFourClosedWithoutPeriodicAlias']
# Reuse the exact frozen candidate-independent foreground function; executing
# only definitions never runs its fitting loop or writes an analysis report.
old_argv = sys.argv
sys.argv = [camera_file]
ns = {'__file__': str(ROOT / camera_file)}
exec((ROOT / camera_file).read_text().split('first = image(rows[args.start])')[0], ns)
sys.argv = old_argv
configs = {
    'training': {'trace': 'evidence/local/lower-next-three-one-support-v4-training-2026-11-06T05-39-11.379Z/trace.jsonl',
                 'reports': ['evidence/lower-next-three-one-v4-training.json', 'evidence/lower-next-three-one-v4-training-crossfit.json']},
    'heldout': {'trace': 'evidence/local/lower-next-three-one-support-v4-heldout-2026-11-06T05-39-09.846Z/trace.jsonl',
                'reports': ['evidence/lower-next-three-one-v4-heldout.json', 'evidence/lower-next-three-one-v4-heldout-crossfit.json']},
}
observations = {}
sources = [freeze_file, closure_file, camera_file, 'tools/lower-next-three-one-recover.py',
           'tools/lower-next-three-one-closure-v5-reportfix.py',
           'evidence/lower-next-three-one-closure-reporter-fix.json',
           'assets/graphics/graphics-manifest.json', 'assets/graphics/metatiles-palette-015.png',
           'data/observed-levels.json', 'data/observed-upper-rows.json', 'data/observed-lower-supplement.json']
for role, config in configs.items():
    sources += [config['trace']] + config['reports']
    reports = [read(p) for p in config['reports']]
    assert all(r['passedThroughEnd'] and r['allTargetPixelsExcludedFromRegistration']
               and r['codeSha256'] == sha(camera_file) for r in reports)
    maps = [{r['tick']: r for r in report['chain']} for report in reports]
    records = list(map(json.loads, (ROOT / config['trace']).read_text().splitlines()))
    assert not any((r.get('player') or {}).get('cell') == 22 for r in records)
    observations[role] = []
    for row in records:
        tick = row.get('response', {}).get('tick', -1)
        player = row.get('player')
        if tick <= 2858 or not player or player.get('confidence') != 1 or 'killed' in player.get('annotation', ''):
            continue
        if any(tick not in m for m in maps):
            continue
        pair = [m[tick] for m in maps]
        if not all(r['eightAnchorEndpoint'] and r['targetImageEvidenceEligible'] for r in pair):
            continue
        origins = []
        for y in range(240):
            candidates = {c for r in pair for c in r['cameraCandidatesByPixelRow'][y]}
            origins.append(next(iter(candidates)) if len(candidates) == 1 else None)
        path = row['image']
        im = np.asarray(Image.open(ROOT / path).convert('RGB'))
        mask = ns['foreground'](im, camera=False)
        mask[max(0, player['visibleTop'] - 4):min(240, player['visibleBottom'] + 4),
             max(0, player['visibleLeft'] - 4):min(256, player['visibleRight'] + 4)] = True
        observations[role].append({'tick': tick, 'nativeFrame': row['nativeFrame'], 'image': path,
                                   'imageSha256': sha(path), 'origins': origins,
                                   'originalChainImage': config['reports'][0],
                                   'independentCrossfitImage': config['reports'][1],
                                   'imageRGB': im, 'dynamicMask': mask})


def actual_proof(x, y, width=16, height=16):
    seen = {role: [[{} for _ in range(width)] for _ in range(height)] for role in observations}
    for role, scene in observations.items():
        for index, obs in enumerate(scene):
            for dy in range(height):
                camera = obs['origins'][y + dy]
                if camera is None:
                    continue
                for dx in range(width):
                    sx = x + dx - camera
                    if not 16 <= sx < 240 or obs['dynamicMask'][y + dy, sx]:
                        continue
                    rgb = tuple(map(int, obs['imageRGB'][y + dy, sx]))
                    seen[role][dy][dx].setdefault(rgb, []).append(index)
    truth = np.zeros((height, width, 3), dtype='uint8')
    proven = np.zeros((height, width), dtype=bool)
    refs = {role: [[[] for _ in range(width)] for _ in range(height)] for role in observations}
    conflicts = []
    for dy in range(height):
        for dx in range(width):
            colors = {rgb for role in seen for rgb in seen[role][dy][dx]}
            if len(colors) > 1:
                conflicts.append({'offset': [dx, dy], 'RGBValues': [list(c) for c in sorted(colors)]})
            elif colors:
                rgb = next(iter(colors))
                truth[dy, dx] = rgb
                for role in refs:
                    refs[role][dy][dx] = seen[role][dy][dx].get(rgb, [])[:2 if role == 'training' else 1]
                proven[dy, dx] = len(refs['training'][dy][dx]) == 2 and len(refs['heldout'][dy][dx]) == 1
    return {'complete': bool(proven.all()), 'provenPixels': int(proven.sum()), 'totalPixels': width * height,
            'contradictionCount': len(conflicts), 'contradictions': conflicts,
            'unwitnessedOffsets': np.argwhere(~proven)[:, ::-1].tolist(), 'pixelWitnesses': refs}, truth


proof, truth = actual_proof(1504, 208)
manifest = read('assets/graphics/graphics-manifest.json')
rects = {m['id']: m['rect'] for m in manifest['metatiles']}
atlas = np.asarray(Image.open(ROOT / 'assets/graphics/metatiles-palette-015.png').convert('RGB'))


def tile(mid):
    x, y, w, h = rects[mid]
    return atlas[y:y + h, x:x + w]


aliases = [mid for mid in rects if np.array_equal(tile(mid), truth)] if proof['complete'] else []
result = {'schema': 'single-observed-support-cell-v1', 'status': 'read-only-candidate-parent-integration-required',
          'sourceHashes': {p: sha(p) for p in sources},
          'sourceWitnesses': {role: [{k: v for k, v in o.items() if k not in ['imageRGB', 'dynamicMask']}
                                     for o in scene] for role, scene in observations.items()},
          'thresholds': {'RGBPixelsPerWholeCell': 256, 'RGBTolerance': 0, 'distinctTrainingTicksPerPixel': 2,
                         'freshIndependentHeldoutTicksPerPixel': 1, 'wholeKnownAnchorsPerImage': 8},
          'cameraTargetExclusion': 'Entire target row208..223 never enters camera learning/comparison; independent preexisting known84row14 supplies additional anchors.',
          'wholeCells': [], 'unresolvedCells': [], 'originalStaticFragmentInventory': [],
          'acceptedRemovals': [], 'consistentOverlapsPreserved': []}
cell = {'level': '3-1', 'area': 'main', 'col': 94, 'row': 13, 'atlas': 'metatiles-palette-015.png',
        'metatileId': 84, 'visualAliases': aliases, 'classification': 'unique-visible-metatile', 'proof': proof,
        'collisionProvenance': 'Ground84descriptor and observed neighboring ground/contact support imply solidity; precise native collision timing is not established by bitmap equality.'}
if proof['complete'] and not proof['contradictionCount'] and aliases == [84]:
    result['wholeCells'].append(cell)
else:
    result['unresolvedCells'].append(cell)
for source in ['data/observed-levels.json', 'data/observed-upper-rows.json', 'data/observed-lower-supplement.json']:
    segment = next(s for l in read(source)['levels'] if l['id'] == '3-1' for s in l['segments'] if s['id'] == 'main')
    for field in ['freeTiles', 'decorations', 'tile8Overrides', 'patternOverrides']:
        for index, piece in enumerate(segment.get(field, [])):
            if isinstance(piece, dict):
                x, y, width, height = piece['x'], piece['y'], 16, 16
                patch = tile(piece['metatileId'])
            else:
                x, y, width, height = piece[0] * 8, piece[1] * 8, 8, 8
                image = np.asarray(Image.open(ROOT / 'assets/graphics' / piece[3]).convert('RGB'))
                px, py = piece[2] % 16 * 8, piece[2] // 16 * 8
                patch = image[py:py + 8, px:px + 8]
            if not (x < 1520 and x + width > 1504 and y < 224 and y + height > 208):
                continue
            item = {'level': '3-1', 'area': 'main', 'sourceFile': source, 'sourceField': field,
                    'sourceIndex': index, 'match': piece, 'footprint': [x, y, width, height]}
            result['originalStaticFragmentInventory'].append(item)
            footprint_proof, observed = actual_proof(x, y, width, height)
            item = {**item, 'referenceProof': footprint_proof}
            assert footprint_proof['complete'] and footprint_proof['contradictionCount'] == 0
            if np.array_equal(patch, observed):
                result['consistentOverlapsPreserved'].append(item)
            else:
                result['acceptedRemovals'].append({**item, 'action': 'remove-whole-fragment',
                                                  'opaqueSourcePixelsDifferentFromObservedReplacement': int(np.any(patch != observed, axis=2).sum())})
FILE = 'data/lower-next-three-one-support.json'
if args.verify:
    assert read(FILE) == result, 'Exact export does not reproduce'
else:
    (ROOT / FILE).write_text(json.dumps(result, indent=2) + '\n')
print(json.dumps({'acceptedWholeCells': len(result['wholeCells']), 'RGBPixels': proof['provenPixels'],
                  'contradictions': proof['contradictionCount'], 'aliases': aliases,
                  'staticOverlaps': len(result['originalStaticFragmentInventory']),
                  'wholeRemovals': len(result['acceptedRemovals']), 'consistentOverlapsPreserved': len(result['consistentOverlapsPreserved'])}))
