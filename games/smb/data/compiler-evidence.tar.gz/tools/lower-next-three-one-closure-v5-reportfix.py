"""All-parent backward closure implementing the prospectively frozen rule."""
import argparse,hashlib,json
from pathlib import Path
ROOT=Path(__file__).resolve().parent.parent
p=argparse.ArgumentParser();p.add_argument('reports',nargs=4);p.add_argument('--out',required=True);a=p.parse_args()
result={'schema':'observed-upper-anchor-backward-closure-v1','rule':'evidence/lower-next-three-one-camera-v5-rule.json','runs':[],'mapPromoted':False}
for file in a.reports:
 r=json.loads((ROOT/file).read_text());assert r['passedThroughEnd']
 chain=r['chain'];allowed=set(chain[-1]['latestCameraCandidates']);reverse=[]
 for q in reversed(chain):
  hs=[h for h in q['hypotheses'] if h['latestCamera'] in allowed]
  assert hs
  current=sorted({h['latestCamera'] for h in hs})
  allowed={v for h in hs for v in h['parentLatestCandidates']}
  reverse.append({'tick':q['tick'],'survivingLatest':current,'parentCandidates':sorted(allowed),'retainedHypotheses':len(hs),'eightPixelAliasRemains':max(current)-min(current)>=8})
 assert allowed=={0},'Does not reconverge to independent camera-zero origin'
 endpoint=chain[-1]
 assert endpoint['eightAnchorEndpoint'] and endpoint['targetImageEvidenceEligible']
 assert all(len(x)==1 for x in endpoint['cameraCandidatesByPixelRow'][208:240])
 periodic=[q for q in reverse if q['eightPixelAliasRemains']]
 result['runs'].append({'report':file,'sha256':hashlib.sha256((ROOT/file).read_bytes()).hexdigest(),'backward':list(reversed(reverse)),'cameraZeroRejoined':True,'remainingPeriodicEightPixelAliases':periodic,'endpointWholeEstablishedAnchors':min(len(h['wholeNonuniformEstablishedAnchors']) for h in endpoint['hypotheses']),'endpointUniqueLowerOrigins':endpoint['cameraCandidatesByPixelRow'][208:240]})
result['allFourClosedWithoutPeriodicAlias']=all(not r['remainingPeriodicEightPixelAliases'] for r in result['runs'])
assert result['allFourClosedWithoutPeriodicAlias'],'Periodic origin remains unresolved'
(ROOT/a.out).write_text(json.dumps(result,indent=2)+'\n');print(json.dumps({'allFourClosedWithoutPeriodicAlias':True,'mapPromoted':False}))
