"""Prospective, all-hypothesis camera chain; target pixels never register themselves."""
import argparse
import hashlib
import itertools
import json
from pathlib import Path

import numpy as np
from PIL import Image

ROOT = Path(__file__).resolve().parent.parent
parser = argparse.ArgumentParser()
parser.add_argument('--trace', default='evidence/local/reference-campaign-dense/trace.jsonl')
parser.add_argument('--extension')
parser.add_argument('--start', type=int, default=6228)
parser.add_argument('--end', type=int, default=6368)
parser.add_argument('--out', default='evidence/lower-next-six-one-training.json')
parser.add_argument('--independent-mosaic')
parser.add_argument('--save-mosaic')
parser.add_argument('--seed-mosaic')
args = parser.parse_args()
palette_image=np.asarray(Image.open(ROOT/'assets/graphics/metatiles-palette-018.png').convert('RGB'))
static_colors={tuple(map(int,p)) for p in palette_image.reshape(-1,3)}
goomba_sheet=np.asarray(Image.open(ROOT/'assets/graphics/enemy-table-0f-0f-36-17.png').convert('RGBA'))
goomba_head=goomba_sheet[32:40,48:64]
goomba_opaque=goomba_head[:,:,3]>0
assert goomba_opaque.sum()>=12
mutable=np.zeros((240,4096),dtype=bool)
trusted_floor=np.zeros((240,4096),dtype=bool)
canonical=json.loads((ROOT/'data/observed-levels.json').read_text())
seg=next(s for l in canonical['levels'] if l['id']=='6-1' for s in l['segments'] if s['id']=='main')
for x,y,mid in seg['tiles']:
    if y==14 and mid==84:trusted_floor[224:240,x*16:x*16+16]=True
    if mid in [82,192,193,194]:
        mutable[max(48,y*16-16):min(208,y*16+32),max(0,x*16-16):min(4096,x*16+32)]=True
# Supplied Lakitu parts independently calibrate the palette-sharing actor mask.
tables=json.loads((ROOT/'assets/graphics/tables.json').read_text())
lakitu_sheet=np.asarray(Image.open(ROOT/'assets/graphics/sprite-tiles-0f-1a-30-27.png').convert('RGBA'))
lakitu_parts=[]
for cell in [24,25]:
    for i,tid in enumerate(tables['enemy_cells'][cell]['tiles']):
        if tid==252:continue
        part=lakitu_sheet[tid//16*8:tid//16*8+8,tid%16*8:tid%16*8+8]
        opaque=part[:,:,3]>0
        if opaque.sum()<15 or len(np.unique(part[:,:,:3][opaque],axis=0))<2:continue
        for flip in [False,True]:
            item=part[:,::-1]if flip else part
            lakitu_parts.append((item,i%2*8,i//2*8))
coin_base=palette_image[96:112,16:32]
coin_mask=np.any(coin_base!=[0,0,0],axis=2)
coin_colors=[(228,92,16),(252,160,68),(240,208,176)]
coin_templates=[]
for dark,light in itertools.product(coin_colors,repeat=2):
    item=coin_base.copy()
    item[np.all(coin_base==[228,92,16],axis=2)]=dark
    item[np.all(coin_base==[252,160,68],axis=2)]=light
    coin_templates.append(item)
piranha_bands=[]
for cell in [32,33]:
    for row in [0,1]:
        parts=[]
        for col in [0,1]:
            tid=tables['enemy_cells'][cell]['tiles'][row*2+col]
            piece=lakitu_sheet[tid//16*8:tid//16*8+8,tid%16*8:tid%16*8+8]
            if col==1:piece=piece[:,::-1]
            parts.append(piece)
        band=np.concatenate(parts,axis=1)
        opaque=band[:,:,3]>0
        assert opaque.sum()>=40 and len(np.unique(band[:,:,:3][opaque],axis=0))>=2
        for flip in [False,True]:piranha_bands.append((band[:,::-1]if flip else band,row*8))
WIDTH = 4096
known = np.zeros((240, WIDTH), dtype=bool)
rgb = np.zeros((240, WIDTH, 3), dtype='uint8')
source_tick = np.zeros((240, WIDTH), dtype='int32')
source_screen_x = np.zeros((240, WIDTH), dtype='int16')


def digest(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def records(path):
    return {r['response']['tick']: r for r in map(json.loads, Path(path).read_text().splitlines()) if r.get('response', {}).get('image')}


rows = records(ROOT / args.trace)
if args.extension:
    rows.update({t: r for t, r in records(ROOT / args.extension).items() if t > args.start})


def image(r):
    return np.asarray(Image.open(r.get('image') or r['response']['image']['capture_path']).convert('RGB'))


def foreground(im, camera=True):
    encoded=im[:,:,0].astype('uint32')+(im[:,:,1].astype('uint32')<<8)+(im[:,:,2].astype('uint32')<<16)
    allowed=np.array([r+(g<<8)+(b<<16) for r,g,b in static_colors],dtype='uint32')
    seed=~np.isin(encoded,allowed)
    padded=np.pad(seed,10)
    mask=np.logical_or.reduce([padded[y:y+240,x:x+256] for y in range(21) for x in range(21)])
    # Actual invariant head match; no world/camera or candidate-color test.
    ys,xs=np.where(np.all(im==goomba_head[2,7,:3],axis=2))
    for sy,sx in zip(ys-2,xs-7):
        if sy<40 or sx<0 or sy+8>224 or sx+16>256:continue
        if np.array_equal(im[sy:sy+8,sx:sx+16][goomba_opaque],goomba_head[:,:,:3][goomba_opaque]):
            mask[max(40,sy-12):min(240,sy+20),max(0,sx-4):min(256,sx+20)]=True
    for part,offset_x,offset_y in lakitu_parts:
        opaque=part[:,:,3]>0
        ay,ax=np.argwhere(opaque)[0]
        ys,xs=np.where(np.all(im==part[ay,ax,:3],axis=2))
        for sy,sx in zip(ys-ay,xs-ax):
            if sy<32 or sx<0 or sy+8>240 or sx+8>256:continue
            if np.array_equal(im[sy:sy+8,sx:sx+8][opaque],part[:,:,:3][opaque]):
                top,left=sy-offset_y,sx-offset_x
                mask[max(32,top-4):min(240,top+28),max(0,left-4):min(256,left+20)]=True
    for coin in coin_templates:
        ay,ax=np.argwhere(coin_mask)[0]
        ys,xs=np.where(np.all(im==coin[ay,ax],axis=2))
        for sy,sx in zip(ys-ay,xs-ax):
            if sy<32 or sx<0 or sy+16>240 or sx+16>256:continue
            if np.array_equal(im[sy:sy+16,sx:sx+16][coin_mask],coin[coin_mask]):
                mask[max(32,sy-4):min(240,sy+20),max(0,sx-4):min(256,sx+20)]=True
    for part,offset_y in piranha_bands:
        opaque=part[:,:,3]>0
        ay,ax=np.argwhere(opaque)[0]
        ys,xs=np.where(np.all(im==part[ay,ax,:3],axis=2))
        for sy,sx in zip(ys-ay,xs-ax):
            if sy<32 or sx<0 or sy+8>240 or sx+16>256:continue
            if np.array_equal(im[sy:sy+8,sx:sx+16][opaque],part[:,:,:3][opaque]):
                top=sy-offset_y
                mask[max(32,top-4):min(240,top+28),max(0,sx-4):min(256,sx+20)]=True
    if camera:
        mask[208:224]=True
        mask[:,:16]=True
        mask[:,240:]=True
    return mask


def learn(im, fg, origins, tick):
    added = 0
    for y in list(range(48,208))+list(range(224,240)):
        if len(origins[y]) != 1:
            continue
        cam = next(iter(origins[y]))
        valid = ~fg[y] & ~mutable[y,cam:cam+256]
        first = ~known[y, cam:cam + 256] & valid
        assert np.all(~known[y, cam:cam + 256][valid] | np.all(rgb[y, cam:cam + 256][valid] == im[y][valid], axis=1))
        added += int(np.count_nonzero(first))
        source_tick[y, cam:cam + 256][first] = tick
        source_screen_x[y, cam:cam + 256][first] = np.arange(256)[first]
        rgb[y, cam:cam + 256][valid] = im[y][valid]
        known[y, cam:cam + 256][valid] = True
    return added


def fit(im, fg, previous, frames):
    bound = int(np.ceil(2.5 * frames))
    reachable = sorted({cam + dx for cam in previous for dx in range(bound + 1) if cam + dx + 256 < WIDTH})
    fits = {}
    for cam in reachable:
        valid = known[:, cam:cam + 256] & ~fg
        mismatch = np.any(rgb[:, cam:cam + 256] != im, axis=2) & valid
        bad = mismatch.ravel()
        indices = np.flatnonzero(bad)
        fits[cam] = [int(indices[0]) if len(indices) else 240 * 256, int(indices[-1]) if len(indices) else -1]
    hypotheses = []
    for latest in reachable:
        for old in range(max(0, latest - 3), latest + 1):
            parents = [p for p in previous if p <= old <= p + int(np.ceil(2.5 * max(0, frames - 1))) and latest <= p + bound]
            if old not in fits or not parents:
                continue
            lower, upper = fits[old][1] + 1, fits[latest][0]
            if lower > upper:
                continue
            anchors = []
            for row in list(range(3,13))+[14]:
                y = row * 16
                for col in range((latest + 15) // 16, (old + 256) // 16):
                    x = col * 16
                    patch = rgb[y:y + 16, x:x + 16]
                    if not np.all(known[y:y + 16, x:x + 16]) or not np.any(patch != patch[0, 0]):
                        continue
                    good = True
                    for yy in range(16):
                        wy = y + yy
                        cams = {latest} if (wy + 1) * 256 <= lower else {old} if wy * 256 >= upper else {latest, old}
                        for cam in cams:
                            sx = x - cam
                            if np.any(fg[wy, sx:sx + 16]) or not np.array_equal(im[wy, sx:sx + 16], patch[yy]):
                                good = False
                                break
                        if not good:
                            break
                    if good:
                        anchors.append([col, row])
            hypotheses.append({'latestCamera': latest, 'previousNativeCamera': old, 'tearRasterPixelRangeInclusive': [lower, upper], 'parentLatestCandidates': parents, 'wholeNonuniformEstablishedAnchors': anchors})
    origins = [set() for _ in range(240)]
    for h in hypotheses:
        lo, hi = h['tearRasterPixelRangeInclusive']
        for y in range(240):
            if y * 256 < hi:
                origins[y].add(h['latestCamera'])
            if (y + 1) * 256 - 1 >= lo:
                origins[y].add(h['previousNativeCamera'])
    return hypotheses, origins


first = image(rows[args.start])
assert not (args.independent_mosaic and args.seed_mosaic)
if args.independent_mosaic or args.seed_mosaic:
    independent = np.load(ROOT / (args.independent_mosaic or args.seed_mosaic))
    known[:] = independent['known']
    rgb[:] = independent['rgb']
    assert not np.any(known[208:224]), 'Targets must never enter registration'
else:
    learn(first, foreground(first), [{0} for _ in range(240)], args.start)
previous = {0}
chain = []
failed = False
for tick in range(args.start + 1, args.end + 1):
    r = rows[tick]
    im = image(r)
    fg = foreground(im)
    frames = r['response']['frames_advanced']
    hypotheses, origins = fit(im, fg, previous, frames)
    if not hypotheses:
        chain.append({'tick': tick, 'failed': True, 'previousLatestCameraCandidates': sorted(previous), 'framesAdvanced': frames, 'reason': 'No exact RGB/native-bound hypothesis. No fallback.'})
        failed = True
        print('FAILED', tick, sorted(previous), flush=True)
        break
    previous = {h['latestCamera'] for h in hypotheses}
    qualified = all(len(h['wholeNonuniformEstablishedAnchors']) >= 8 for h in hypotheses)
    target_eligible=qualified
    added = 0 if args.independent_mosaic else learn(im, fg, origins, tick)
    observation = {'tick': tick, 'framesAdvanced': frames, 'nativeFrame': r.get('nativeFrame'), 'latestCameraCandidates': sorted(previous), 'cameraCandidatesByPixelRow': [sorted(o) for o in origins], 'hypotheses': hypotheses, 'eightAnchorEndpoint': qualified, 'targetImageEvidenceEligible': target_eligible, 'newProvisionalUpperPixelsOnlyAtAllHypothesisUniqueOrigin': added, 'sourceImage': r.get('image') or r['response']['image']['capture_path']}
    chain.append(observation)
    print(tick, 'latest', sorted(previous), 'floor208', sorted(origins[208]), 'hypotheses', len(hypotheses), 'anchors', min(len(h['wholeNonuniformEstablishedAnchors']) for h in hypotheses), 'new', added, flush=True)
result = {'schema': 'lower-next-six-one-palette-chain-calibration-v1', 'status': 'training-diagnostic-no-map-export', 'rule': 'evidence/lower-next-six-one-camera-v9-rule.json','foregroundRule':'Actual RGB outside suppliedpalette018 dilation10 plus exactGoombaheadboxes and calibrated exactsuppliedLakitu parts; wholetargetrow208..223excluded;row224..239usesONLYpreviouslyobserved84cells; mutablecanonicalblocks+16haloexcluded.', 'codeSha256': digest(__file__), 'sourceTraces': [{'path': args.trace, 'sha256': digest(ROOT / args.trace)}] + ([{'path': args.extension, 'sha256': digest(ROOT / args.extension)}] if args.extension else []), 'startTick': args.start, 'startCamera': 0, 'allTargetPixelsExcludedFromRegistration': True, 'chain': chain, 'passedThroughEnd': not failed and bool(chain) and chain[-1]['tick'] == args.end, 'seedMosaic':args.seed_mosaic,'seedMosaicSha256':digest(ROOT/args.seed_mosaic) if args.seed_mosaic else None,'independentMosaic': args.independent_mosaic, 'independentMosaicSha256': digest(ROOT / args.independent_mosaic) if args.independent_mosaic else None, 'qualifiedForAcceptance': False, 'reason': 'Requires independent fresh camera-zero heldout chain and backward closure. Diagnostic does not accept cells.'}
(ROOT / args.out).write_text(json.dumps(result, indent=2) + '\n')

if args.save_mosaic:
    np.savez_compressed(ROOT / args.save_mosaic, known=known, rgb=rgb, source_tick=source_tick, source_screen_x=source_screen_x)
