"""Independent direct-PNG, controller, whole-footprint and target-exclusion checks."""
import hashlib,json
from datetime import datetime
from pathlib import Path
import numpy as np
from PIL import Image
ROOT=Path(__file__).resolve().parent.parent
FILE='data/lower-next-six-two-continuation-v3-support.json'
def read(path):return json.loads((ROOT/path).read_text())
def sha(path):return hashlib.sha256((ROOT/path).read_bytes()).hexdigest()
doc=read(FILE)
for path,digest in doc['sourceHashes'].items():assert sha(path)==digest,path
freeze=read('evidence/lower-next-six-two-continuation-v3-freeze.json')
for path,digest in freeze['files'].items():assert sha(path)==digest,path
closure=read('evidence/lower-next-six-two-continuation-v3-closure.json');assert closure['allClosed'] and len(closure['runs'])==4
assert not doc['unresolvedCells'] and len(doc['wholeCells'])==2
cells={(c['col'],c['row']):c for c in doc['wholeCells']}
assert set(cells)=={(c,13)for c in range(152,154)}
manifest=read('assets/graphics/graphics-manifest.json');atlas=np.asarray(Image.open(ROOT/'assets/graphics/metatiles-palette-018.png').convert('RGB'))
rects={m['id']:m['rect']for m in manifest['metatiles']}
def tile(mid):
 x,y,w,h=rects[mid];return atlas[y:y+h,x:x+w]
for c in cells.values():
 assert c['level']=='6-2' and c['area']=='main' and c['metatileId']in[0,84]
 aliases=[mid for mid in rects if np.array_equal(tile(mid),tile(c['metatileId']))]
 assert aliases==c['visualAliases']
 if c['metatileId']==0:assert c['classification']=='uniform-observed-background' and np.all(tile(0)==0)
 else:assert c['classification']=='unique-visible-metatile' and aliases==[84]
images={};chains={};pixel_checks=0;used_hashes={'training':set(),'heldout':set()}
def verify(proof,wx,wy,width,height):
 global pixel_checks
 assert proof['complete'] and proof['provenPixels']==proof['totalPixels']==width*height
 assert not proof['contradictionCount'] and not proof['unwitnessedOffsets']
 assert 208<=wy and wy+height<=224
 for dy in range(height):
  for dx in range(width):
   for role,minimum in [('training',2),('heldout',1)]:
    indices=proof['pixelWitnesses'][role][dy][dx];assert len(indices)>=minimum
    assert len({doc['sourceWitnesses'][role][i]['tick']for i in indices})>=minimum
    for index in indices:
     obs=doc['sourceWitnesses'][role][index];assert obs['tick']>=6665
     used_hashes[role].add(obs['imageSha256'])
     if obs['image']not in images:
      assert sha(obs['image'])==obs['imageSha256'];images[obs['image']]=np.asarray(Image.open(ROOT/obs['image']).convert('RGB'))
     camera=obs['origins'][wy+dy];assert camera is not None and 16<=wx+dx-camera<240
     for path in [obs['originalChainImage'],obs['independentCrossfitImage']]:
      if path not in chains:
       report=read(path);assert report['passedThroughEnd'] and report['allTargetPixelsExcludedFromRegistration']
       assert not report.get('seedMosaic'),'No common auxiliary source declared'
       chains[path]={r['tick']:r for r in report['chain']}
       mosaic=report['independentMosaic']
       if mosaic:
        assert sha(mosaic)==report['independentMosaicSha256']
        assert not np.any(np.load(ROOT/mosaic)['known'][208:224])
      row=chains[path][obs['tick']];assert row['eightAnchorEndpoint'] and row['targetImageEvidenceEligible']
      assert row['cameraCandidatesByPixelRow'][wy+dy]==[camera]
      assert all(len(h['wholeNonuniformEstablishedAnchors'])>=8 for h in row['hypotheses'])
     actual=images[obs['image']][wy+dy,wx+dx-camera]
     expected=tile(cells[((wx+dx)//16,(wy+dy)//16)]['metatileId'])[(wy+dy)%16,(wx+dx)%16]
     assert np.array_equal(actual,expected);pixel_checks+=1
for (col,row),cell in cells.items():verify(cell['proof'],col*16,row*16,16,16)
assert not used_hashes['training']&used_hashes['heldout'],'Reserved repeated history must be visibly independent'
for action in doc['consistentOverlapsPreserved']+doc['acceptedRemovals']:
 source=read(action['sourceFile']);seg=next(s for l in source['levels']if l['id']=='6-2'for s in l['segments']if s['id']=='main')
 assert seg[action['sourceField']][action['sourceIndex']]==action['match']
 verify(action['referenceProof'],*action['footprint'])
 if action in doc['acceptedRemovals']:assert action['action']=='remove-whole-fragment' and action['opaqueSourcePixelsDifferentFromObservedReplacement']>0
winning=read('data/observed-winning-inputs.json')['actions'];names=['up','down','left','right','a','b','x','y','start','select'];prefixes=0
original={r['response']['tick']:r for r in map(json.loads,(ROOT/'evidence/local/reference-campaign-dense/trace.jsonl').read_text().splitlines())if r.get('response',{}).get('image')}
for path in doc['sourceHashes']:
 if not(path.startswith('evidence/local/')and path.endswith('trace.jsonl')):continue
 records=list(map(json.loads,(ROOT/path).read_text().splitlines()));total=0;prefix=[];controls=[];endpoint=None;role=records[-1]['role'];per_tick={}
 assert all(datetime.fromisoformat(r['sentUtc'].replace('Z','+00:00'))>datetime.fromisoformat(freeze['createdUtc'].replace('Z','+00:00')) for r in records)
 for row in records:
  req,rep=row['request'],row['response']
  if req['op']=='reset':total=0
  total+=rep.get('frames_advanced',0);assert row['nativeFrame']==total
  if req['op']=='step':
   mask=sum(1<<names.index(b)for b in req['buttons']);assert rep['applied_masks']==[mask]*req['ticks']
   assert 7*req['ticks']<=rep['frames_advanced']<=8*req['ticks']
   if row['mode']in['prefix','endpoint']:prefix+=rep['applied_masks']
   if row['mode']=='control':
    controls+=rep['applied_masks'];assert row['player']['confidence']==1 and row['player']['cell']!=22;per_tick[rep['tick']]=row
  if row['mode']=='endpoint':endpoint=row
 assert prefix==[a[0]for a in winning[:6658]] and endpoint['nativeFrame']==sum(a[1]for a in winning[:6658])
 assert sha(endpoint['image'])==sha(original[6658]['response']['image']['capture_path'])
 anchor=next(r for r in records if r['response'].get('tick')==6504)
 assert sha(anchor['image'])==sha(original[6504]['response']['image']['capture_path'])
 brake,neutral=(4,2)if role=='training'else(5,1)
 assert controls==[36]*brake+[0]*neutral+[16]*4+[0]*2
 assert records[-1]['response']['tick']==6670 and records[-1]['player']['cell']!=22
 assert per_tick[6664]['player']['visibleBottom']==176
 assert per_tick[6665]['player']['visibleBottom']<176 and per_tick[6668]['player']['visibleBottom']<per_tick[6665]['player']['visibleBottom']
 assert all(row['player']['cell']!=22 for row in per_tick.values())
 prefixes+=1
assert prefixes==2
report={'export':FILE,'exportSha256':sha(FILE),'wholeRecoveredCells':len(cells),'solidGroundCells':sum(c['metatileId']==84 for c in cells.values()),'observedBackgroundCells':sum(c['metatileId']==0 for c in cells.values()),'directRGBWitnessChecks':pixel_checks,'RGBMismatchCount':0,'independentFreshStandardPrefixes':prefixes,'allFourCameraChainsClosed':True,'targetRowNeverEnteredCameraMosaics':True,'minimumWholeAnchors':8,'consistentOriginalWholeFragmentsPreserved':len(doc['consistentOverlapsPreserved']),'wholeProvedRemovals':len(doc['acceptedRemovals']),'unprovedOrClippedRemovals':0,'allFrozenSourcesUnchanged':True,'actualJumpsObservedFromFeet176':True,'noAuxiliaryCameraSourceOrFixedRasterBand':True,'browserIntegrationStillRequired':True}
(ROOT/'evidence/lower-next-six-two-continuation-v3-verification.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report))
