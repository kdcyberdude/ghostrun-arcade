/** Admit only independently exact upper-static camera origins; flames/base never choose camera. */
import fs from 'node:fs';import crypto from 'node:crypto';import assert from 'node:assert/strict';
const read=p=>JSON.parse(fs.readFileSync(p)),sha=p=>crypto.createHash('sha256').update(fs.readFileSync(p)).digest('hex');
const [config,out]=process.argv.slice(2),plan=read(config),sourceWitnesses={},sourceHashes={[config]:sha(config)};
for(const item of plan.histories){
 const trace=fs.readFileSync(item.trace,'utf8').trim().split('\n').map(JSON.parse),records=new Map(trace.map(r=>[r.response.tick,r]));
 const chains=[item.chain,item.crossfit].map(path=>{sourceHashes[path]=sha(path);const report=read(path);assert.equal(report.passedThroughEnd,true);assert.deepEqual(report.excludedWorldRectangle,[288,160,48,48]);return report;});
 sourceHashes[item.trace]=sha(item.trace);const cross=new Map(chains[1].chain.map(r=>[r.tick,r]));let checked=0;
 sourceWitnesses[item.name]=chains[0].chain.map(row=>{
  const other=cross.get(row.tick),record=records.get(row.tick);assert.ok(other&&record);assert.ok(row.hypotheses.every(h=>h.wholeNonuniformEstablishedAnchors.length>=8));assert.ok(other.hypotheses.every(h=>h.wholeNonuniformEstablishedAnchors.length>=8));
  const origins=row.cameraCandidatesByPixelRow.map((o,y)=>{const all=new Set([...o,...other.cameraCandidatesByPixelRow[y]]);return all.size===1?[...all][0]:null;});
  const image=record.response.image.capture_path;checked++;
  return {tick:row.tick,nativeFrame:record.nativeFrame,image,imageSha256:sha(image),origins,originalChainImage:row.sourceImage,independentCrossfitImage:other.sourceImage,stage:record.stage,latestCameraCandidates:row.latestCameraCandidates};
 });
 assert.ok(checked>0);
}
fs.writeFileSync(out,JSON.stringify({schema:'three-four-independent-source-registry-v1',qualification:'Every admitted row origin unique across original and independent crossfit hypotheses; all hops have8static anchors; target neighborhood never learned. Dynamic sprite epoch is separate.',sourceHashes,sourceWitnesses},null,2)+'\n');
console.log(out,Object.fromEntries(Object.entries(sourceWitnesses).map(([k,v])=>[k,v.length])));
