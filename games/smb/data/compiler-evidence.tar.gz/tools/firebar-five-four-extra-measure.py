"""Read-only additional5-4 flame inventory; cameras come only from frozen upper chains."""
import collections, datetime, hashlib, json, math, pathlib, sys
import numpy as np
from PIL import Image

ROOT = pathlib.Path(__file__).resolve().parent.parent
def read(path):
    return json.loads((ROOT / path).read_text())
def sha(path):
    return hashlib.sha256((ROOT / path).read_bytes()).hexdigest()

plan_path = sys.argv[1]
plan = read(plan_path)
assert sha(plan['source']) == plan['sourceSHA256'], 'Frozen source registry changed'
source = read(plan['source'])
patterns = []
for phase in range(4):
    path = f'assets/graphics/special/sprite-fireball_or_firebar-{phase}.png'
    rgba = np.array(Image.open(ROOT / path).convert('RGBA'))
    opaque = np.argwhere(rgba[:, :, 3] == 255)
    counts = collections.Counter(map(tuple, rgba[:, :, :3][rgba[:, :, 3] == 255]))
    rare = min(counts, key=counts.get)
    ay, ax = np.argwhere((rgba[:, :, 3] == 255) & np.all(rgba[:, :, :3] == rare, axis=2))[0]
    patterns.append((phase, rgba[:, :, :3], opaque, int(ay), int(ax)))

pivots = plan['candidateActualCentersFromIndependentStaticBases']
lookup = read('data/firebar-motion-rules.json')['lookup']
reports = []
for role in source['sourceWitnesses']:
    rows = []
    for witness_index, witness in enumerate(source['sourceWitnesses'][role]):
        assert sha(witness['image']) == witness['imageSha256'], 'Source PNG changed'
        im = np.array(Image.open(ROOT / witness['image']).convert('RGB'))
        found = {}
        for phase, rgb, opaque, ay, ax in patterns:
            pos = np.argwhere(np.all(im[48:240] == rgb[ay, ax], axis=2))
            ys, xs = pos[:, 0] + 48 - ay, pos[:, 1] - ax
            valid = (xs >= 0) & (ys >= 48) & (xs + 8 <= 256) & (ys + 8 <= 240)
            ys, xs = ys[valid], xs[valid]
            for yy, xx in opaque:
                valid = np.all(im[ys + yy, xs + xx] == rgb[yy, xx], axis=1)
                ys, xs = ys[valid], xs[valid]
            for x, y in zip(xs, ys):
                origins = witness['origins'][int(y):int(y) + 8]
                if any(origin is None for origin in origins) or len(set(origins)) != 1:
                    continue
                wx, wy = int(x) + origins[0] + 4, int(y) + 4
                point = found.setdefault((wx, wy), {'actualCenter': [wx, wy], 'sourceTopLeft': [int(x), int(y)], 'independentRowOrigin': origins[0], 'opaquePixels': len(opaque), 'spritePhases': []})
                point['spritePhases'].append(phase)
        assemblies, unassigned, ambiguous = [], [], []
        for pivot in pivots:
            points = []
            for point in found.values():
                dx, dy = point['actualCenter'][0] - pivot[0], point['actualCenter'][1] - pivot[1]
                radius = math.hypot(dx, dy)
                node = round(radius / 8)
                if node <= 5 and abs(radius - node * 8) < 2:
                    points.append({**point, 'relative': [dx, dy], 'radiusIndex': node})
            points.sort(key=lambda point: point['radiusIndex'])
            phase_candidates = [phase for phase in range(32) if points and all(list(lookup[phase][point['radiusIndex']]) == point['relative'] for point in points)]
            assemblies.append({'actualPivot': pivot, 'points': points, 'uniqueRadiusIndices': sorted(set(point['radiusIndex'] for point in points)), 'shapePhaseCandidates': phase_candidates})
        for point in found.values():
            owners = [assembly['actualPivot'] for assembly in assemblies if any(p['actualCenter'] == point['actualCenter'] for p in assembly['points'])]
            if not owners:
                unassigned.append(point)
            if len(owners) > 1:
                ambiguous.append({'point': point, 'owners': owners})
        rows.append({'witnessIndex': witness_index, 'tick': witness['tick'], 'nativeFrame': witness['nativeFrame'], 'image': witness['image'], 'imageSHA256': witness['imageSha256'], 'originalChainImage': witness['originalChainImage'], 'independentCrossfitImage': witness['independentCrossfitImage'], 'assemblies': assemblies, 'unassigned': unassigned, 'ambiguous': ambiguous})
    summaries = []
    for pivot in pivots:
        assemblies = [(row, next(a for a in row['assemblies'] if a['actualPivot'] == pivot)) for row in rows]
        complete = [row['tick'] for row, assembly in assemblies if assembly['uniqueRadiusIndices'] == list(range(6))]
        centers = sum(len(assembly['points']) for _, assembly in assemblies)
        coherent = sum(len(assembly['shapePhaseCandidates']) == 1 for _, assembly in assemblies)
        summaries.append({'actualPivot': pivot, 'completeSixNodeTicks': complete, 'centerSamples': centers, 'coherentShapeObservations': coherent})
    simultaneous = [row['tick'] for row in rows if all(assembly['uniqueRadiusIndices'] == list(range(6)) for assembly in row['assemblies'])]
    reports.append({'role': role, 'rows': rows, 'assemblies': summaries, 'allDeclaredSixNodeSimultaneousTicks': simultaneous})

result = {'schema': 'five-four-extra-admitted-flame-measurements-v1', 'date': datetime.datetime.now(datetime.timezone.utc).isoformat(), 'plan': plan_path, 'planSHA256': sha(plan_path), 'source': plan['source'], 'sourceSHA256': sha(plan['source']), 'toolSHA256': sha('tools/firebar-five-four-extra-measure.py'), 'qualification': 'Image inventory only. Centers use frozen independently matched row origins; supplied opaque flame RGB matches prove six separate nodes. No camera learned from flames or bases, no runtime edits, no prospective phase-validation or collision claim.', 'reports': reports}
out = sys.argv[2]
(ROOT / out).write_text(json.dumps(result, indent=2) + '\n')
print(json.dumps({'out': out, 'reports': [{key: value for key, value in report.items() if key != 'rows'} for report in reports]}, indent=2))
