"""Ordinary reference controls; capture every decision near3-4; no state API."""
import argparse, datetime, json, pathlib, shutil, subprocess

parser = argparse.ArgumentParser()
parser.add_argument('--plan', required=True)
parser.add_argument('--cases', nargs='+')
parser.add_argument('--interactive', action='store_true')
args = parser.parse_args()
root = pathlib.Path(__file__).resolve().parent.parent
plan = json.loads((root / args.plan).read_text())
actions = json.loads((root / 'data/observed-winning-inputs.json').read_text())['actions']
out = root / 'evidence/local' / ('firebar-three-four-fresh-' + datetime.datetime.now(datetime.timezone.utc).strftime('%Y-%m-%dT%H-%M-%S.%fZ'))
out.mkdir(parents=True)
proc = subprocess.Popen([str(root / 'run-model.sh'), '/home/kd/Desktop/proj/llm_gameplay/roms/mario.nes'], cwd=root, stdin=subprocess.PIPE, stdout=subprocess.PIPE, stderr=(out / 'stderr.log').open('w'), text=True, bufsize=1)
trace = (out / 'trace.jsonl').open('w', buffering=1)
native, sequence, name, stage = 0, 0, 'initial', 'hello'
def call(request):
    global native, sequence
    if request['op'] == 'reset':
        native = 0
    sent = datetime.datetime.now(datetime.timezone.utc).isoformat()
    proc.stdin.write(json.dumps(request) + '\n')
    proc.stdin.flush()
    line = proc.stdout.readline()
    if not line:
        raise RuntimeError('Reference closed')
    response = json.loads(line)
    if not response.get('ok'):
        raise RuntimeError(line)
    native += response.get('frames_advanced', 0)
    if response.get('image', {}).get('path'):
        path = out / f'{sequence:05d}-{name}-{stage}-t{response.get("tick",0):05d}.png'
        shutil.copyfile(response['image']['path'], path)
        response['image']['capture_path'] = str(path)
    trace.write(json.dumps({'sequence': sequence, 'case': name, 'stage': stage, 'sentUtc': sent, 'nativeFrame': native, 'request': request, 'response': response}) + '\n')
    sequence += 1
    return response
try:
    call({'op': 'hello'})
    for case in plan['cases']:
        if args.cases and case['name'] not in args.cases:
            continue
        name, stage = case['name'], 'prefix'
        call({'op': 'reset'})
        i = 0
        while i < plan['prefixDecisions']:
            end = i + 1
            while end < plan['prefixDecisions'] and end - i < 240 and actions[end][0] == actions[i][0] and end < plan['captureFromTick'] - 1:
                end += 1
            response = call({'op': 'step', 'mask': actions[i][0], 'ticks': end-i})
            assert response['frames_advanced'] == sum(action[1] for action in actions[i:end]), 'Prefix native duration changed'
            i = end
        for segment in case['segments']:
            stage = segment['stage']
            for _ in range(segment['ticks']):
                response = call({'op': 'step', 'buttons': segment['buttons'], 'ticks': 1})
        print(json.dumps({'directory': str(out), 'case': name, 'lastTick': response['tick'], 'lastNativeFrame': native, 'lastImage': response['image']['capture_path']}), flush=True)
    if args.interactive:
        import sys
        stage = 'manual'
        for line in sys.stdin:
            request = json.loads(line)
            stage = request.pop('stage', 'manual')
            response = call(request)
            print(json.dumps({'nativeFrame': native, 'response': response}), flush=True)
finally:
    proc.stdin.close()
    proc.terminate()
    proc.wait()
    trace.close()
